import { useEffect, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import TodoList from './components/TodoList/TodoList'
import NewItem from './components/NewItems/NewItem'
import { nanoid } from 'nanoid'
import {toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
toast.configure()
//model.id = nanoid() //=> "V1StGXR8_Z5jdHi6B-myT"

const DEFAULT_LIST=[{
  title:'Study JavaScript',
  priority:"high",
  id:nanoid()
},
{
  title:'Study CSS',
  priority:"low",
  id:nanoid()
},
{
title:'Study MongoDB',
priority:"medium",
id:nanoid()
}]

function App() {

  const [list,setList]=useState([])
  const [editState,setEditState]=useState({})
  //console.log("edit state1"+editState)
  useEffect(()=>{
    fetch('http://localhost:3500/api/v2/todo').then(res=>{
      return res.json()
    }).then((res)=>{console.log(res);setList(res);}).catch=(err)=>{console.log(err)}
  },[])

  const deleteItem=(id)=>{
    console.log(id)
   // console.log(id)
    fetch('http://localhost:3500/api/v2/todo/' + id, {
  method: 'DELETE',
})
.then(res => res.json()) // or res.json()
 .then(res => {
  setList([...res])
})
  
  }

  const addItem=(item)=>{
    //item.id=nanoid()
    fetch('http://localhost:3500/api/v2/todo',{
      method:"POST",
      headers:{
        Accept:'application/json,text/plain,*/*',
        "Content-Type":'application/json'
      },
      body:JSON.stringify(item)
  }).then(()=>{
    console.log(item)
    setList((prev)=>[item,...prev])
    toast.success("Added successfully")
  }).catch((err)=>console.log(err))
  }
    

  const editItem=(updatedItem)=>{
    console.log(updatedItem.id)
    fetch('http://localhost:3500/api/v2/todo/' +updatedItem.id, {
      method: 'PATCH',
      headers:{
        "Accept":'application/json,text/plain,*/*',
        "Content-Type":'application/json'
      },
      body:JSON.stringify(updatedItem)
    }).then(()=>{
      //setList((prev)=>[...prev])
      toast.success("Added successfully")
    }).catch((err)=>console.log(err))
      // const updatedlist=list.map((item)=>{
      //   if(item.id==updatedItem.id){
      //     return updatedItem
      //   }
      //   else{
      //     return item
      //   }
      // })

      //setList([...updatedlist])
  }

 const triggerEdit=(item)=>{
  console.log(item)
  console.log(item._id)
  setEditState(item)
 // console.log("edit state2"+setEditState.title)
 }

  return (
  <div className='app'>
  <h1 className="title">Todo List</h1>
  <NewItem  addItem={addItem} editState={editState} editItem={editItem}/>
  <TodoList list={list} deleteItem={deleteItem} triggerEdit={triggerEdit} />
 

  </div>
 
  )
}

export default App


// console.log(id)
// fetch('http://localhost:3500/api/v2/todo' + id, {
// method: 'DELETE',
// })
// .then(res => res.json()) // or res.json()
// .then(res => {console.log(res);setList((prev)=>{[...prev]})})